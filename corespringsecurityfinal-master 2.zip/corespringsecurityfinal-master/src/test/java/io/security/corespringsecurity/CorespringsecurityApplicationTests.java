package io.security.corespringsecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CorespringsecurityApplicationTests {

    @Test
    void contextLoads() {
    }

}
