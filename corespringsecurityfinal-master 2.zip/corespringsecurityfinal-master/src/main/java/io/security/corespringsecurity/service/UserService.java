package io.security.corespringsecurity.service;

import io.security.corespringsecurity.domain.Account;

public interface UserService {

    public void createUser(Account account);
}
