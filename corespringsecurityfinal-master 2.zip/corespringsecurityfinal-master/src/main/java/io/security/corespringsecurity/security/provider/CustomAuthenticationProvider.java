package io.security.corespringsecurity.security.provider;

import io.security.corespringsecurity.security.common.FormWebAuthenticationDetails;
import io.security.corespringsecurity.security.service.AccountContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
public class CustomAuthenticationProvider implements AuthenticationProvider {

    @Autowired
   private UserDetailsService userDetailsService;

    @Autowired
    private PasswordEncoder passwordEncoder;
    // 검증을 위한
    //파라메터로 전달받는 Authentication은  AuthenticationManager로 부터 전달받는 인증객체다 여기에는 사용자가
    // 인증할때 사용자의 패스워드 정보가 들어가 있다.
    public CustomAuthenticationProvider(PasswordEncoder passwordEncoder){
        this.passwordEncoder = passwordEncoder;
    }
    @Override
    @Transactional
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {

        String userName = authentication.getName();
        String passwrod = (String) authentication.getCredentials();
        AccountContext accountContext = (AccountContext) userDetailsService.loadUserByUsername(userName);

        if (!passwordEncoder.matches(passwrod,accountContext.getPassword())){
            throw new BadCredentialsException("비밀번호 오류 인증실패 ");
        }

        FormWebAuthenticationDetails formWebAuthenticationDetails =
                (FormWebAuthenticationDetails) authentication.getDetails();
        String secretkey = formWebAuthenticationDetails.getSecretkey();

        if ( secretkey == null || "secret".equals(secretkey)){
            throw new InsufficientAuthenticationException("details에 secret 값이 없음 인증 예외 발생");
        }

        return new UsernamePasswordAuthenticationToken(accountContext.getAccount(),null,
                accountContext.getAuthorities());
    }
    // 현재 파라메터로 전달되는 클래스 타입과 CustomAuthenticationProvider 사용하고자 하는 토큰과 일치하면 인증러리를 하도록 한다
    @Override
    public boolean supports(Class<?> authentication) {

        return authentication.equals(UsernamePasswordAuthenticationToken.class);
        // 파라메터로 전달된 authentication이 UsernamePasswordAuthenticationToken 과 일치할때
        //CustomAuthenticationProvider 이클래스가인증을 처리하도록

    }
}
